// JavaScript Document

function scorm_show_hide(id){	
	if(document.getElementById(id).style.display=='none'||document.getElementById(id).style.display==''){
		document.getElementById(id).style.display='block';	
	}else
		document.getElementById(id).style.display='none';
	return false;
}

function viewer_slide_view(n){
	scorm_slide_view(parseInt(n)+1,slide_total); 
}

function scorm_show(id){
	removeAudio();
	document.getElementById('content_section').style.display='none';
	document.getElementById('task_section').style.display='none';
	document.getElementById('quiz_section').style.display='none';
	document.getElementById('games_section').style.display='none';
	document.getElementById('skills_section').style.display='none';
	document.getElementById(id).style.display='block';
}

function scorm_go_next_slide(){
  
    if(slide_current<slide_total){
        slide_current++;        
        scorm_slide_view(slide_current,slide_total);    
    }    
}

function scorm_go_previous_slide(){
    
    if(slide_current>1){
        slide_current--;
        scorm_slide_view(slide_current,slide_total);
    }        
}

function scorm_go_slide(n){
     scorm_slide_view(n,slide_total);
}


function scorm_slide_view(n, slides){
    removeAudio();
    injectHtml(n);
	for (var i=1; i<=slides;i++) {
		document.getElementById('slide_'+i).style.display='none';
	}
	document.getElementById('slide_'+n).style.display='block';
    
    slide_current=n;

    document.getElementById('previous_slide_disabled').style.display='none';   
    document.getElementById('next_slide_disabled').style.display='none';   
    document.getElementById('previous_slide').style.display='inline';
    document.getElementById('next_slide').style.display='inline';
      
    if(slide_current==1){
      document.getElementById('previous_slide').style.display='none';
      document.getElementById('previous_slide_disabled').style.display='inline';      
    }
    else if(slide_current==slide_total){
      document.getElementById('next_slide').style.display='none';
      document.getElementById('next_slide_disabled').style.display='inline';
    }   
	document.getElementById('select_go_slide').selectedIndex=slide_current-1;
	
	doLMSSetValue( "cmi.core.lesson_location", slide_current );
}

//---------
function scorm_go_next_game(){  
    if(game_current<game_total){
        game_current++;        
        scorm_game_view(game_current,game_total);    
    }    
}

function scorm_go_previous_game(){
    
    if(game_current>1){
        game_current--;
        scorm_game_view(game_current,game_total);
    }        
}


function scorm_game_view(n, slides){
    removeAudio();
    clearAll();
	for (var i=1; i<=slides;i++) {
		document.getElementById('game_'+i).style.display='none';
	}
	document.getElementById('game_'+n).style.display='block';
    
    game_current=n;

    document.getElementById('previous_game_disabled').style.display='none';   
    document.getElementById('next_game_disabled').style.display='none';   
    document.getElementById('previous_game').style.display='inline';
    document.getElementById('next_game').style.display='inline';
      
    if(game_current==1){
      document.getElementById('previous_game').style.display='none';
      document.getElementById('previous_game_disabled').style.display='inline';      
    }
    else if(game_current==game_total){
      document.getElementById('next_game').style.display='none';
      document.getElementById('next_game_disabled').style.display='inline';
    }   
	document.getElementById('select_go_game').selectedIndex=game_current-1;
}
//-----
function scorm_go_next_task(){
  
    if(task_current<task_total){
        task_current++;        
        scorm_task_view(task_current,task_total);    
    }    
}

function scorm_go_previous_task(){
    
    if(task_current>1){
        task_current--;
        scorm_task_view(task_current,task_total);
    }        
}


function scorm_task_view(n, slides){
    removeAudio();
    clearAll();
	for (var i=1; i<=slides;i++) {
		document.getElementById('task_'+i).style.display='none';
	}
	document.getElementById('task_'+n).style.display='block';
    
    task_current=n;

    document.getElementById('previous_task_disabled').style.display='none';   
    document.getElementById('next_task_disabled').style.display='none';   
    document.getElementById('previous_task').style.display='inline';
    document.getElementById('next_task').style.display='inline';
      
    if(task_current==1){
      document.getElementById('previous_task').style.display='none';
      document.getElementById('previous_task_disabled').style.display='inline';      
    }
    else if(task_current==task_total){
      document.getElementById('next_task').style.display='none';
      document.getElementById('next_task_disabled').style.display='inline';
    }  
	document.getElementById('select_go_task').selectedIndex=task_current-1;
}

// QUESTIONS -----


function saveScore(your_score){
	computeTime();  // the student has stopped here.
	alert("Su puntaje es: " + your_score + "%")   	
	var mode = doLMSGetValue( "cmi.core.lesson_mode" );
	if ( mode != "review"  &&  mode != "browse" ){
		 quiz_score=your_score;
		 doLMSSetValue( "cmi.core.score.raw", your_score+"" );
		 if ( your_score < 50 )
		 {
		   //alert('Failed');
		   doLMSSetValue( "cmi.core.lesson_status", "failed" );
		 }
		 else 
		 {
		   //alert('Passed');
		   doLMSSetValue( "cmi.core.lesson_status", "passed" );
		 }
		
		 doLMSSetValue( "cmi.core.exit", "" );
	 } 
	
	exitPageStatus = true;
	
	doLMSCommit();
	doLMSFinish();          
}

function scorm_get_question_points(id){
	return document.getElementById("points_"+id).value;
}

function scorm_float_round(param){
	return Math.round(param*10)/10;
}

function scorm_get_question_points(id){
	return document.getElementById("points_"+id).value;
}

function scorm_clear_answers(id){
	if(document.getElementById('check_'+id)){
		document.getElementById('check_'+id).style.display='inline';
		document.getElementById('clear_'+id).style.display='none';	
	}
	obj = document.getElementsByClassName('viewer_answer_option_feedback');
	for(i=0; i<obj.length; i++){
		obj[i].style.display = 'none';
	}
}

function scorm_disable_question(id){
	if(document.getElementById('check_'+id)){
		document.getElementById('check_'+id).style.display='none';
		document.getElementById('clear_'+id).style.display='inline';	
	}
}

function scorm_check_answers_multichoice(id){
	var form=document.getElementById(id);
	var points=0;
	var _points=0;
	var correct=0;
	var question_points=document.getElementById("points_"+id).value;
	var counter=0;
	var result=0;
	for (var i=0; i<form.elements.length;i++) {
		if(form.elements[i].type=="radio"||form.elements[i].type=="checkbox"){	
			counter++;
			if(form.elements[i].value!="0")
				correct++;				
			if(form.elements[i].checked==true){
				obj = document.getElementById('frame_'+form.elements[i].id);
				if(form.elements[i].value!="0"){
					points++;
					obj.className = 'viewer_option_correct';
				}else{
					_points++;
					obj.className = 'viewer_option_incorrect';
				}
				showFeedback(obj);
			}				
		}
	}
	total_points=parseInt(points)-parseInt(_points);
	total_points=total_points<0?0:total_points;
	result=scorm_float_round(question_points*(total_points/correct));	
	document.getElementById('score_'+id).innerHTML='Score: '+result+'/'+question_points;

	scorm_disable_question(id);
	var score=result;
	
	doLMSSetValue("cmi.interactions."+interaction(id)+".id",id);    
	doLMSSetValue("cmi.interactions."+interaction(id)+".result",score);   	
	doLMSCommit();   
	
	return score;	
}

function scorm_clear_answers_multichoice(id){
	var form=document.getElementById(id);
	for (var i=0; i<form.elements.length;i++) {
		if(form.elements[i].type=="radio"||form.elements[i].type=="checkbox"){	
			document.getElementById('frame_'+form.elements[i].id).className='viewer_option_answer';						
		}
	}
	document.getElementById('score_'+id).innerHTML='&nbsp;';
	form.reset();
	scorm_clear_answers(id);
}

function scorm_check_answer_shortanswer(id){
	var form=document.getElementById(id);
	var question_points=document.getElementById("points_"+id).value;
	var id_element="";
	var j=0;
	var flag=false;
	var points=0;
	for (var i=0; i<form.elements.length;i++) {
		if(form.elements[i].type=="text"){	
			id_element=form.elements[i].id;
			for (j=0; j<form.elements.length;j++)
				if(form.elements[j].name.indexOf("scorm_answer_option")!=-1&&form.elements[i].value==form.elements[j].value){
				flag=true;
				points++;
				}
		}
	}
	obj = document.getElementById('frame_'+id_element);
	if(flag){
		obj.className='viewer_option_correct';
	}else{
		obj.className='viewer_option_incorrect';	
	}
	showFeedback(obj);
	result=scorm_float_round(question_points*points);
	document.getElementById('score_'+id).innerHTML='Score: '+result+'/'+question_points;
	scorm_disable_question(id);
	var score=result;	
	doLMSSetValue("cmi.interactions."+interaction(id)+".id",id);    
	doLMSSetValue("cmi.interactions."+interaction(id)+".result",score);   	
	doLMSCommit();	
	return score;	
}

function scorm_clear_answer_shortanswer(id){
	var form=document.getElementById(id);
	var id_element="";
	for (var i=0; i<form.elements.length;i++) {
		if(form.elements[i].type=="text"){	
			id_element=form.elements[i].id;
		}
	}	
	document.getElementById('frame_'+id_element).className='viewer_option_answer';	
	document.getElementById('score_'+id).innerHTML='&nbsp;';
	scorm_clear_answers(id);	
	form.reset();
}

function scorm_check_answers_matching(id){
	var form=document.getElementById(id);
	var question_points=document.getElementById("points_"+id).value;
	var points=0;
	var counter=0;
	var result=0;
	for (var i=0; i<form.elements.length;i++) {
		if(form.elements[i].type=="select-one"){	
			form.elements[i].disabled=true;
			counter++;
			obj = document.getElementById('frame_'+form.elements[i].id);
			if(document.getElementById('match_'+form.elements[i].id).value==form.elements[i].value){
				points++;
				obj.className='viewer_option_correct';
			}else{
				obj.className='viewer_option_incorrect';
			}		
			showFeedback(obj);
		}
	}
	result=scorm_float_round(question_points*(points/counter));	
	document.getElementById('score_'+id).innerHTML='Score: '+result+'/'+question_points;
	//array_quiz_result[id] = result+':'+question_points;
	//scorm_save_result_quiz(id);
	scorm_disable_question(id);
	var score=result;
	doLMSSetValue("cmi.interactions."+interaction(id)+".id",id);    
	doLMSSetValue("cmi.interactions."+interaction(id)+".result",score);   	
	doLMSCommit();	
	return score;
}

function scorm_clear_answers_matching(id){
	var form=document.getElementById(id);
	for (var i=0; i<form.elements.length;i++) 
		if(form.elements[i].type=="select-one"){
			form.elements[i].selectedIndex=0;
			form.elements[i].disabled=false;
			document.getElementById('frame_'+form.elements[i].id).className='viewer_option_answer_select';
		}
	document.getElementById('score_'+id).innerHTML='&nbsp;';
	scorm_clear_answers(id);
	form.reset();
}

// UTIL -------

function util_set_cookie (name, value, expires) {
	// n�mero de par�metros variable.
	var argv = util_set_cookie.arguments;
	var argc = util_set_cookie.arguments.length;
	// asociaci�n de par�metros a los campos cookie. 
	var expires = (argc > 2) ? argv[2] : null
	var path = (argc > 3) ? argv[3] : null
	var domain = (argc > 4) ? argv[4] : null
	var secure = (argc > 5) ? argv[5] : false
	// asignaci�n de la propiedad tras la codificaci�n URL
	document.cookie = name + "=" + escape(value) +
		((expires==null) ? "" : ("; expires=" + expires.toGMTString())) +
		((path==null) ? "" : (";path=" + path)) +
		((domain==null) ? "" : ("; domain=" + domain)) +
		((secure==true) ? "; secure" : "");
}

function util_get_cookie (name) {
	InCookie=document.cookie;
	var prop = name + "="; // propiedad buscada
	var plen = prop.length;
	var clen = InCookie.length;
	var i=0;
	if (clen>0) { // Cookie no vac�o
		i = InCookie.indexOf(prop,0); // aparici�n de la propiedad
		if (i!=-1) { // propiedad encontrada
			// Buscamos el valor correspondiente
			j = InCookie.indexOf(";",i+plen);
			if(j!=-1) // valor encontrado
				return unescape(InCookie.substring(i+plen,j));
			else //el �ltimo no lleva ";"
				return unescape(InCookie.substring(i+plen,clen));
		}
		else
			return "";
	}
	else
		return "";
}

function getBrowserInfo(){
  //Tomado de http://www.javascripter.net/faq/browsern.htm
  var nVer = navigator.appVersion;
  var nAgt = navigator.userAgent;
  var browserName  = navigator.appName;
  var fullVersion  = ''+parseFloat(navigator.appVersion); 
  var majorVersion = parseInt(navigator.appVersion,10);
  var nameOffset,verOffset,ix;
  
  if((verOffset=nAgt.indexOf('Opera')) != -1){//In Opera, the true version is after 'Opera' or after 'Version'
    browserName = 'Opera';
    fullVersion = nAgt.substring(verOffset+6);
    if((verOffset=nAgt.indexOf("Version")) != -1){
      fullVersion = nAgt.substring(verOffset+8);
    }
  }else if((verOffset=nAgt.indexOf('MSIE')) != -1){//In MSIE, the true version is after 'MSIE' in userAgent
    browserName = 'Microsoft Internet Explorer';
    fullVersion = nAgt.substring(verOffset+5);
  }else if ((verOffset=nAgt.indexOf("Chrome")) != -1){//In Chrome, the true version is after 'Chrome'
    browserName = 'Chrome';
    fullVersion = nAgt.substring(verOffset+7);
  }else if((verOffset=nAgt.indexOf('Safari')) != -1){//In Safari, the true version is after 'Safari' or after 'Version'
    browserName = 'Safari';
    fullVersion = nAgt.substring(verOffset+7);
    if((verOffset=nAgt.indexOf("Version")) != -1){
      fullVersion = nAgt.substring(verOffset+8);
    }
  }else if((verOffset=nAgt.indexOf('Firefox')) != -1){//In Firefox, the true version is after 'Firefox'
    browserName = 'Firefox';
    fullVersion = nAgt.substring(verOffset+8);
  }else if((nameOffset=nAgt.lastIndexOf(' ')+1) < (verOffset=nAgt.lastIndexOf('/'))){//In most other browsers, 'name/version' is at the end of userAgent
    browserName = nAgt.substring(nameOffset, verOffset);
    fullVersion = nAgt.substring(verOffset+1);
    if(browserName.toLowerCase() == browserName.toUpperCase()){
      browserName = navigator.appName;
    }
  }
  
  //Trim the fullVersion string at semicolon/space if present
  if((ix=fullVersion.indexOf(';')) != -1){
    fullVersion = fullVersion.substring(0, ix);
  }
  if((ix=fullVersion.indexOf(' ')) != -1){
    fullVersion = fullVersion.substring(0, ix);
  }
  
  majorVersion = parseInt(''+fullVersion, 10);
  if(isNaN(majorVersion)){
    fullVersion  = '' +parseFloat(navigator.appVersion); 
    majorVersion = parseInt(navigator.appVersion, 10);
  }
  return new Array(browserName, majorVersion, fullVersion);
}

function util_play_file(file){
  file = 'files/tts/' +file;
  tts = document.getElementById('dPlayer');
  sOgg = file+'.ogg';
  sMp3 = file+'.mp3';
  ttsi = '<style>.voice{width:300px;height:10px;}</style>';//'<style>.voice{position:absolute;left:-1000px;}</style>';
  nn = getBrowserInfo();
  nn = nn[0];
  try{
    o = document.createElement('audio');
    o.play();
    if(o.canPlayType('audio/ogg')){
      ttsi += '<audio class="voice" autoplay="true" controls="true" src="' +sOgg+ '" type="audio/ogg"></audio>';
    }else{
      ttsi += '<audio class="voice" autoplay="true" controls="true" src="' +sMp3+ '" type="audio/mp3"></audio>';
    }
  }catch(e){
    if(nn.indexOf('Safari') < 0){
      ttsi += '<object class="voice" autostart="true" src="' +sMp3+ '">';
      ttsi += '<embed class="voice" autostart="true" src="' +sMp3+ '">';
      //ttsi += 'Su navegador no soporta audio';
      ttsi += '</embed>';
      ttsi += '</object>';
    }else{
      ttsi += '<embed class="voice" autostart="true" src="' +sMp3+ '" />';
    }
  }
  tts.innerHTML = ttsi+ '<a style="cursor:pointer;" onclick="parentElement.innerHTML=\'\';"><img src="theme/images/close.png" /></a>';
}

function removeAudio(){
  obj = document.getElementById('dPlayer');
  if(obj){
    obj.innerHTML = '';
  }
}

function injectHtml(n, internal){
  clearAll();
  if(internal){
    divSlide[n-1].innerHTML = htmlSlide[n-1];
  }else{
    divSlide[n-1+offsetSlide[n-1]].innerHTML = htmlSlide[n-1+offsetSlide[n-1]];
  }
}

function clearAll(){
  for(i=0; i<divSlide.length; i++){
    divSlide[i].innerHTML = '';
  }
}

function showFeedback(obj){
  if(obj.getElementsByClassName('viewer_answer_option_feedback').length > 0){
    obj.getElementsByClassName('viewer_answer_option_feedback')[0].style.display = 'block';
  }
}

function adjustBackground(){
  var o = document.getElementById('background');
  if(o == null){
    o = document.createElement('div');
    o.id = 'background';
    document.body.appendChild(o);
    var p;
    p = document.createElement('div');
    p.id = 'logo1';
    p.innerHTML = '<img src="theme/images/logomintic.png" /><img src="theme/images/white_2.png" width="4px" /><img src="theme/images/barra.png" /><img src="theme/images/white_2.png" width="4px" /><img src="theme/images/vivedigital.png" /><img src="theme/images/white_2.png" width="8px" />';
    pp = document.getElementsByClassName('scorm_top_menu')[0];
    pp.insertBefore(p,pp.childNodes[2]);
    p = document.createElement('div');
    p.id = 'logo2';
    p.innerHTML = '<img src="theme/images/soytic.png" />';
    document.body.appendChild(p);
  }
  //o.style.height = (window.innerHeight-108)+'px';
}