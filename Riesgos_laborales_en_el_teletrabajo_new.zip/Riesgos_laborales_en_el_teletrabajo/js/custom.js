Array.prototype.has = function(v) {
	for (i = 0; i < this.length; i++){
		if (this[i] == v) {
			return true;
		}
	}
	
	return false;
}

var prev = [];
var trans = new Array(new Array());

var showInternal = function(i, c){
	var div = parseInt(i) + 1;
	if(c==undefined || c==1){
		$('.scorm_slide_content').hide();
		$('#previous_slide').show();
		$('#previous_slide_disabled').hide();
		$('#internal_'+div).show();
	}else{
		var x = 0;
		for(i=0; i<trans.length; i++){
			if(trans[i][0] == div){
				x = trans[i][1];
				break;
			}
		}
		prev.splice(0);
		$('.internal_link').hide();
		scorm_slide_view(x, slide_total);
	}
	removeAudio();
	injectHtml(div, true);
}

divSlide = new Array();
htmlSlide = new Array();
offsetSlide = new Array();
$(document).ready(function(){
	divSlide = $('.scorm_slide_content');
	var hidden = new Array();
	var noHidden = new Array();
	var sel = $('#select_go_slide');
	var iniTotal = sel.find('option').length;
	
	sel.removeAttr('onchange');
	sel.change(function(){
		$('.internal_link').hide();
		scorm_slide_view($(this).val(), slide_total);
	});
	
	$('#previous_slide').attr('href', '#!');
	$('#previous_slide').click(function(){
		$('.internal_link').hide();
		var prevIndex = 0;
		
		if (prev.length > 0) {
			$('.scorm_slide_content').hide();
			prevIndex = prev.length - 1;
			slide = prev[prevIndex].attr('id').split('_');
			slideId = slide.pop();
			slideType = slide.pop();
			if(slideType == 'internal'){
				showInternal(slideId-1);
			}else{
				scorm_slide_view(slideId, slide_total);
			}
			//prev[prevIndex].show();
			prev.splice(prevIndex, 1);
			
			if(prev.length == 0 && slide_current == 1){
				$('#previous_slide').hide();
				$('#previous_slide_disabled').show();
			}
		} else {
			scorm_go_previous_slide();
		}
	});
	
	$('#next_slide').attr('href', '#!');
	$('#next_slide').click(function(){
		prev.splice(0);
		$('.internal_link').hide();
		scorm_go_next_slide();
	});
	
	$('a[href*="showInternal"]').each(function(){
		var str = $(this).attr('href');
		var slide = str.substr(25);
		var sep = slide.indexOf(',');
		if(sep != -1){
			var ocu = slide.substr(sep+1).charAt(0);
			slide = slide.substr(0, sep);
			slide = parseInt(slide) + 1;
			if(! hidden.has(slide) && ! noHidden.has(slide)){
				if (ocu == 1) {
					hidden.push(slide);
				}else{
					noHidden.push(slide);
				}
			}
		}else{
			slide = parseInt(slide.substring(0, slide.length-2))+1;
			if (! hidden.has(slide) && ! noHidden.has(slide)) {
				hidden.push(slide);
			}
		}
		$(this).attr('onclick', 'prev.push($(this).parents(\'div[id*="internal"], div[id*="slide"]\'));');
		/*$(this).click(function(){
			var parent = $(this).parents('div[id*="internal"], div[id*="slide"]');
			prev.push(parent);
		});*/
	});
	
	slide_total = iniTotal - hidden.length;
	var counter = 1;
	
	sel.find('option').each(function(){
		var label = ($(this).text()).split('-');
		label.splice(0, 1);
		label = label.join('-');
		var s = $(this).val();
		if (hidden.has(s)) {
			$('#slide_'+s).attr('id', 'internal_'+s);
			$('#internal_'+s).addClass('internal_link');
			$(this).remove();
		}else if(noHidden.has(s)){
			$(this).text(counter+' de '+slide_total+' -'+label);
			$(this).val(counter);
			trans.push();
			trans[trans.length-1].push(s);
			trans[trans.length-1].push(counter);
			$('#slide_'+s).attr('id', 'slide_'+counter);
			$('#slide_'+counter).addClass('internal_link_'+s);
			counter++;
		} else {
			$(this).text(counter+' de '+slide_total+' -'+label);
			$(this).val(counter);
			$('#slide_'+s).attr('id', 'slide_'+counter);
			counter++;
		}
	});
	
	$('.internal_link').hide();
	$('#slide_1').show();
	
	$('.contentTable li').each(function(){
		var _target = $(this).attr('class');
		/*$(this).find('a').attr('href', '#!').click(function(){
			viewer_slide_view(_target); 
		});*/
		as = $(this).find('a');
		as.attr('href', '#!');
		as.attr('onclick', 'viewer_slide_view('+_target+');');
	});
	
	$('table.banner div.child').css('background','url(js/banner-bg.png) no-repeat');
	$('div.diplobanner').css('background','url(js/diplobanner.png) no-repeat bottom');
        acumulado = 0;
	for(i=0; i<divSlide.length; i++){
		o = divSlide[i];
		htmlSlide.push(o.innerHTML);
		if(i != 0){
			o.innerHTML = '';
		}
		if(o.className.indexOf('internal_link') != -1){
                        acumulado++;
		}else{
			offsetSlide[i-acumulado] = acumulado;
		}
	}
});